"""Verify YIZ AI's configured S3-compatible object storage.

Usage:
  python scripts/check_s3_storage.py

Reads the same environment variables used by the application. It creates a
small temporary object under the configured prefix, reads it back, verifies
its contents, and deletes it.
"""
import os
import uuid

import boto3
from botocore.config import Config

endpoint = os.getenv("S3_ENDPOINT_URL", "").strip() or None
bucket = os.getenv("S3_BUCKET", "").strip()
region = os.getenv("S3_REGION", "auto").strip() or "auto"
access = os.getenv("S3_ACCESS_KEY_ID", "").strip() or None
secret = os.getenv("S3_SECRET_ACCESS_KEY", "").strip() or None
prefix = os.getenv("S3_PREFIX", "yiz-ai").strip("/")

if not bucket:
    raise SystemExit("S3_BUCKET is required")
if not access or not secret:
    raise SystemExit("S3_ACCESS_KEY_ID and S3_SECRET_ACCESS_KEY are required")

client = boto3.client(
    "s3",
    endpoint_url=endpoint,
    region_name=region,
    aws_access_key_id=access,
    aws_secret_access_key=secret,
    config=Config(signature_version="s3v4", retries={"max_attempts": 3, "mode": "standard"}),
)

key = f"{prefix}/_health/{uuid.uuid4().hex}.txt" if prefix else f"_health/{uuid.uuid4().hex}.txt"
payload = b"YIZ AI object storage health check"

try:
    client.put_object(Bucket=bucket, Key=key, Body=payload, ContentType="text/plain", CacheControl="no-store")
    response = client.get_object(Bucket=bucket, Key=key)
    body = response["Body"].read()
    if body != payload:
        raise RuntimeError("object-store readback did not match uploaded bytes")
    client.delete_object(Bucket=bucket, Key=key)
    print(f"OK: S3-compatible storage is writable and readable: s3://{bucket}/{key}")
except Exception:
    try:
        client.delete_object(Bucket=bucket, Key=key)
    except Exception:
        pass
    raise
