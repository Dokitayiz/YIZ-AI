# YIZ AI → Cloudflare R2 production setup

1. Create the private bucket `yiz-ai-production` in Cloudflare R2.
2. Create an R2 API token restricted to that bucket with Object Read & Write.
3. Copy the S3 endpoint shown by Cloudflare; it has the form `https://<ACCOUNT_ID>.r2.cloudflarestorage.com`.
4. In Render, create/link a production environment group and add the storage variables from `storage/r2/production.env.example`.
5. Link the storage environment group to **yiz-api** and **yiz-worker**.
6. Redeploy both services.
7. From a shell with the same variables, run:

   `python scripts/check_s3_storage.py`

8. Upload a file through YIZ AI, generate one media artifact, download it, and confirm it still works after an API restart/redeploy.

Render supports environment groups for sharing environment variables across services, and secrets should be entered in the Render dashboard rather than committed to `render.yaml`.
