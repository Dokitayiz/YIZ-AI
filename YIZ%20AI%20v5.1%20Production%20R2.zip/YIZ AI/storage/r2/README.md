# YIZ AI production object storage — Cloudflare R2

YIZ AI is configured to use any S3-compatible object store. This directory provides a production-ready Cloudflare R2 profile.

## Recommended production bucket

Use a private bucket named:

`yiz-ai-production`

Do not make the bucket public. YIZ AI authorizes access through the API and the object-store credentials stay server-side.

## Create the bucket

Cloudflare Dashboard → R2 → Overview → Create bucket → `yiz-ai-production`.

Then create an R2 API token scoped to **Object Read & Write** for this bucket only. Keep the Access Key ID and Secret Access Key private.

The S3 endpoint is:

`https://<ACCOUNT_ID>.r2.cloudflarestorage.com`

Set:

```env
MEDIA_STORAGE=s3
S3_ENDPOINT_URL=https://<ACCOUNT_ID>.r2.cloudflarestorage.com
S3_BUCKET=yiz-ai-production
S3_REGION=auto
S3_ACCESS_KEY_ID=<R2_ACCESS_KEY_ID>
S3_SECRET_ACCESS_KEY=<R2_SECRET_ACCESS_KEY>
S3_PREFIX=yiz-ai
```

These variables should be configured on both the API and worker services. Do not put real credentials in `render.yaml`, Git, Dockerfiles, or frontend code.

## Security model

- Bucket remains private.
- Objects are stored under `yiz-ai/<owner-id>/...`.
- PostgreSQL records ownership metadata.
- `/api/media/...` checks the authenticated owner before returning an object.
- S3 credentials are never sent to browsers.
- For future direct browser transfers, use short-lived presigned URLs rather than exposing bucket credentials.

## Local testing

The project's Docker Compose stack uses MinIO, an S3-compatible local service, so production storage behavior can be tested without R2 credentials.
