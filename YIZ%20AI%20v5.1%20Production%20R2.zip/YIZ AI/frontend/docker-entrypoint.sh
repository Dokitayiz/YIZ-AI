#!/bin/sh
set -eu
api_url="${YIZ_API_INTERNAL_URL:-http://yiz-api:8000}"
cat > /etc/nginx/conf.d/default.conf <<EOF2
server {
  listen 80;
  server_name _;
  root /usr/share/nginx/html;
  index index.html;
  client_max_body_size 30m;

  location /api/ {
    proxy_pass ${api_url};
    proxy_http_version 1.1;
    proxy_set_header Host \$host;
    proxy_set_header X-Real-IP \$remote_addr;
    proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto \$scheme;
    proxy_set_header Connection "";
    proxy_buffering off;
    proxy_request_buffering off;
    proxy_read_timeout 900s;
    proxy_send_timeout 900s;
  }

  location / {
    try_files \$uri \$uri/ /index.html;
  }
}
EOF2
cat > /usr/share/nginx/html/config.js <<'EOF2'
window.YIZ_API_URL = "";
EOF2
